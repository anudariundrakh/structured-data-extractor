"""Structured data extractor package."""
